document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('add-payment-form');
    const paymentRecords = document.getElementById('payment-records');

    // Fetch and display payments
    async function fetchPayments() {
        const response = await fetch('/get_payments');
        const payments = await response.json();
        paymentRecords.innerHTML = '';
        payments.forEach(payment => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${payment.company}</td>
                <td>${payment.amount}</td>
                <td>${payment.payment_date || 'N/A'}</td>
                <td>${payment.due_date}</td>
                <td>${payment.status}</td>
            `;
            paymentRecords.appendChild(row);
        });
    }

    // Add new payment
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        const response = await fetch('/add_payment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        const result = await response.json();
        alert(result.message);
        fetchPayments();
        form.reset();
    });

    fetchPayments();
});
