from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tax_payments.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Database Model
class TaxPayment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    payment_date = db.Column(db.String(20))
    due_date = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False)

# Routes
@app.route('/')
def home():
    """Render the homepage with navigation buttons."""
    return render_template('index.html')

@app.route('/add_payment', methods=['GET', 'POST'])
def add_payment():
    """Handle adding new payments."""
    if request.method == 'GET':
        return render_template('add_payment.html')
    elif request.method == 'POST':
        data = request.json
        new_payment = TaxPayment(
            company=data['company'],
            amount=float(data['amount']),
            payment_date=data.get('payment_date'),
            due_date=data['due_date'],
            status=data['status']
        )
        db.session.add(new_payment)
        db.session.commit()
        return jsonify({'message': 'Payment added successfully!'})

@app.route('/manage_payments', methods=['GET'])
def manage_payments():
    """Render the manage payments page."""
    return render_template('manage_payments.html')

@app.route('/get_payments', methods=['GET'])
def get_payments():
    """Return all payment records as JSON."""
    payments = TaxPayment.query.all()
    return jsonify([
        {
            'id': payment.id,
            'company': payment.company,
            'amount': payment.amount,
            'payment_date': payment.payment_date,
            'due_date': payment.due_date,
            'status': payment.status
        }
        for payment in payments
    ])

@app.route('/delete_payment/<int:id>', methods=['DELETE'])
def delete_payment(id):
    """Delete a specific payment record."""
    payment = TaxPayment.query.get(id)
    if payment:
        db.session.delete(payment)
        db.session.commit()
        return jsonify({'message': 'Payment deleted successfully!'})
    return jsonify({'message': 'Payment not found!'}), 404

@app.route('/edit_payment/<int:id>', methods=['GET', 'POST'])
def edit_payment(id):
    """Handle editing a specific payment."""
    payment = TaxPayment.query.get_or_404(id)
    if request.method == 'POST':
        data = request.json
        payment.company = data['company']
        payment.amount = float(data['amount'])
        payment.payment_date = data.get('payment_date')
        payment.due_date = data['due_date']
        payment.status = data['status']
        db.session.commit()
        return jsonify({'message': 'Payment updated successfully!'})
    return render_template('edit_payment.html', payment=payment)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
