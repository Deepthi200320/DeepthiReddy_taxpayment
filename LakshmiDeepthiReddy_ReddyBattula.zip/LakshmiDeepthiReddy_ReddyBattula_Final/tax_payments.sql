-- Export data
CREATE TABLE tax_payments_backup AS SELECT * FROM tax_payments;

-- Drop the original table
DROP TABLE tax_payments;

-- Create the new table with the tax_rate column
CREATE TABLE IF NOT EXISTS tax_payments (
    id INTEGER PRIMARY KEY, -- This will auto-increment automatically in SQLite
    company TEXT NOT NULL,
    amount REAL NOT NULL,
    payment_date TEXT,
    status TEXT NOT NULL CHECK (status IN ('paid', 'unpaid')),
    due_date TEXT NOT NULL,
    tax_rate REAL NOT NULL DEFAULT 0.0 -- Adding the tax_rate column with a default value
);


-- Re-import data (assigning a default tax_rate)
INSERT INTO tax_payments (id, company, amount, payment_date, status, due_date, tax_rate)
SELECT id, company, amount, payment_date, status, due_date, 0.0 FROM tax_payments_backup;

-- Drop the backup table
DROP TABLE tax_payments_backup;

SELECT * FROM tax_payments;

